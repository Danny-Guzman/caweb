// External Dependencies
//import React, { Fragment } from 'react';
import  CAWEeb_Component from '../component.jsx';

class CAWeb_Module_Fullwidth_Service_Tiles_Item extends CAWEeb_Component {

  static slug = 'et_pb_ca_fullwidth_service_tiles_item';


  render() {
		return;
  }
}

export default CAWeb_Module_Fullwidth_Service_Tiles_Item;
