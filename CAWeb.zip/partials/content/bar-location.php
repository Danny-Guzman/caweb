<?php
/**
 * CAWeb Location Bar
 *
 * @package CAWeb
 */

if ( ! get_option( 'ca_geo_locator_enabled', false ) ) {
	return;
}
?>
<!-- Location Bar -->
<div id="locationSettings" class="section section-standout collapse collapsed"></div>
